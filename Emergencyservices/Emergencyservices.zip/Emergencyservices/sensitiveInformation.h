const char* host = "ISHP";
const char* ssid = "RoboRange";        // Wifi Network Name
const char* password = "Password01";         // Wifi Password


const char* http_username = "admin1";
const char* http_password = "admin1";
